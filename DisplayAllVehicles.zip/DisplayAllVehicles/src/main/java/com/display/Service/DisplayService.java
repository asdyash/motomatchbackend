package com.display.Service;


import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import com.display.Client.VehicleClient;
import com.display.DTO.VehicleDTO;

import java.util.List;

@Service
@RequiredArgsConstructor
public class DisplayService {

    private final VehicleClient vehicleClient;

    public List<VehicleDTO> fetchAllVehicles() {
        return vehicleClient.getAllVehicles();
    }
}
