package com.reviewService.DTO;

import lombok.Data;

@Data
public class ReviewDTO {
    private String id;
    private String vehicleId;
    private String username;
    private int rating;
    private String comment;
}

