package com.vehicleService.Security;



import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Service;

import java.security.Key;

@Service
public class JwtService {

    private final String SECRET = "94c7b8ff89e6dd2e9f7342f7a5bce02c26f6a451e18db430d98569cc8a6cfc55";

    public Claims extractAllClaims(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(getSignKey())
                .build()
                .parseClaimsJws(token)
                .getBody();
    }

    private Key getSignKey() {
        return Keys.hmacShaKeyFor(SECRET.getBytes());
    }
    public String extractRole(String token) {
        String role= extractAllClaims(token).get("role", String.class);
//        System.out.println(role);
        return role;
    }

}
