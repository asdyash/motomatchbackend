package com.vehicleService.Repo;




import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.vehicleService.Entity.VehicleEntity;

public interface VehicleRepo extends MongoRepository<VehicleEntity, String> {

	Optional<VehicleEntity> findById(String id);
	
    
}
