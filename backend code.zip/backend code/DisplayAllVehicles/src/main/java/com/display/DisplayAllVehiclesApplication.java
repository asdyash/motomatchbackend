package com.display;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
@EnableFeignClients
@SpringBootApplication
public class DisplayAllVehiclesApplication {

	public static void main(String[] args) {
		SpringApplication.run(DisplayAllVehiclesApplication.class, args);
	}

}
