package com.vehicleService.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vehicleService.Entity.VehicleEntity;
import com.vehicleService.Repo.VehicleRepo;

import java.util.List;
import java.util.Optional;

@Service
public class VehicleService {

    @Autowired
    private VehicleRepo vehicleRepository;

    // Create a new vehicle
    public VehicleEntity createVehicle(VehicleEntity vehicle) {
        return vehicleRepository.save(vehicle);
    }

    // Get all vehicles
    public List<VehicleEntity> getAllVehicles() {
        return vehicleRepository.findAll();
    }

    // Get a vehicle by its ID
    public Optional<VehicleEntity> getVehicleById(String id) {
        return vehicleRepository.findById(id);
    }

    // Update an existing vehicle
    public VehicleEntity updateVehicle(String id, VehicleEntity vehicleDetails) {
        Optional<VehicleEntity> vehicle = vehicleRepository.findById(id);
        if (vehicle.isPresent()) {
        	
            return vehicleRepository.save(vehicleDetails);
        }
        return null; // or throw an exception if vehicle not found
    }

    // Delete a vehicle
    public void deleteVehicle(String id) {
        vehicleRepository.deleteById(id);
    }
}
