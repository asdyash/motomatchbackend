package com.reviewService.DTO;

import lombok.Data;

@Data
public class VehicleDTO {
    private String id;
    private String name;
    private String brand;
    private String model;
    private int year;
    private String description;
    private String type;
}
