package com.userservice.Service;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.userservice.DTO.AuthResponse;
import com.userservice.DTO.LoginRequest;
import com.userservice.DTO.RegisterRequest;
import com.userservice.Model.UserEntity;
import com.userservice.Repo.UserRepo;
import com.userservice.Security.JWTUtil;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserService  {

    private final UserRepo repo;
    private final PasswordEncoder encoder;
    private final AuthenticationManager authManager;
    private final JWTUtil jwtUtil;

    
    public UserEntity register(RegisterRequest request) {
        if (repo.existsByUsername(request.getUsername())) {
            throw new RuntimeException("Username already exists");
        }

        UserEntity user = UserEntity.builder()
                .username(request.getUsername())
                .email(request.getEmail())
                .password(encoder.encode(request.getPassword()))
                .role(
                    request.getRole() != null && !request.getRole().isBlank()
                        ? request.getRole().toUpperCase()
                        : "USER"
                )
                .build();


        return repo.save(user);
//        String token = jwtUtil.generateToken(user.getUsername(),user.getRole());
//        return new AuthResponse(token);
        
    }

 
    public String login(LoginRequest request) {
        authManager.authenticate(
            new UsernamePasswordAuthenticationToken(
                request.getUsername(), request.getPassword()
            )
        );

        // ✅ Fetch user from DB to get correct role
        UserEntity user = repo.findByUsername(request.getUsername())
                .orElseThrow(() -> new RuntimeException("User not found"));

        String token = jwtUtil.generateToken(user.getUsername(), user.getRole());
//        System.out.print(token);
        return token;
    }

}