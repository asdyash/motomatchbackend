package com.userservice.Repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.userservice.Model.UserEntity;

public interface UserRepo extends JpaRepository<UserEntity, Long> {
    Optional<UserEntity> findByUsername(String username);
    boolean existsByUsername(String username);
    boolean existsByEmail(String email);
}