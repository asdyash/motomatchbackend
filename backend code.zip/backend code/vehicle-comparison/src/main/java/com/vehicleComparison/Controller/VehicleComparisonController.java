package com.vehicleComparison.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vehicleComparison.Service.VehicleComparisonService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/compare")
@RequiredArgsConstructor
public class VehicleComparisonController {

    private final VehicleComparisonService comparisonService;

    @GetMapping("/{id1}/{id2}")
    public String compareVehicles(@PathVariable String id1, @PathVariable String id2) {
        return comparisonService.compareVehicles(id1, id2);
    }
}