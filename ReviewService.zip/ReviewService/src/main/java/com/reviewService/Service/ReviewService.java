package com.reviewService.Service;



import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import com.reviewService.Client.VehicleServiceClient;
import com.reviewService.DTO.VehicleDTO;
import com.reviewService.Model.Review;
import com.reviewService.Repo.ReviewRepo;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ReviewService {

	private final ReviewRepo reviewRepository;
    private final VehicleServiceClient vehicleServiceClient;

    // Submit a new review for a vehicle
    public Review submitReview(Review review) {
        review.setCreatedAt(LocalDateTime.now());
        VehicleDTO vehicleDetails = vehicleServiceClient.getVehicleById( review.getVehicleId());
        review.setVehicleDetails(vehicleDetails);
        return reviewRepository.save(review);
    }

    // Get reviews by vehicle ID and vehicle details from VehicleService
    public List<Review> getReviewsByVehicle(String vehicleId) {
        // Fetch vehicle details from VehicleService
        VehicleDTO vehicleDetails = vehicleServiceClient.getVehicleById(vehicleId);

        // Fetch reviews from the local review repository
        List<Review> reviews = reviewRepository.findByVehicleId(vehicleId);

        // Attach vehicle details to each review 
        reviews.forEach(review -> review.setVehicleDetails(vehicleDetails));

        return reviews;
    }

	public List<Review> getAllReviews() {
		
		return reviewRepository.findAll();
	}
}

