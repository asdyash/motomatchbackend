package com.vehicleComparison;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehicleComparisonApplicationTests {

	@Test
	void contextLoads() {
	}

}
