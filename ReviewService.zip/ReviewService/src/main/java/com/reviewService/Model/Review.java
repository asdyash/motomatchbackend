package com.reviewService.Model;



import jakarta.validation.constraints.*;
import lombok.*;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;

import com.reviewService.DTO.VehicleDTO;

import java.time.LocalDateTime;
@Data
@Document(collection = "reviews")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Review {

    @Id
    private String id;

    @NotBlank(message = "Vehicle ID is required")
    private String vehicleId;

    @NotBlank(message = "Username is required")
    private String username;

    @Min(value = 1, message = "Rating must be at least 1")
    @Max(value = 5, message = "Rating must be at most 5")
    private int rating;

    @Size(max = 500, message = "Review text must not exceed 500 characters")
    private String reviewText;
    
    private LocalDateTime createdAt;
    @Transient
    private VehicleDTO vehicleDetails;  
    @CreatedDate
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }

    public void setVehicleDetails(VehicleDTO vehicleDetails) {
        this.vehicleDetails = vehicleDetails;
    }
}
