package com.reviewService.Repo;




import org.springframework.data.mongodb.repository.MongoRepository;

import com.reviewService.Model.Review;

import java.util.List;

public interface ReviewRepo extends MongoRepository<Review, String> {
    List<Review> findByVehicleId(String vehicleId);
}
