package com.display.Client;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.display.DTO.VehicleDTO;

import java.util.List;

@FeignClient(name = "VehicleService", url = "http://localhost:8087")
public interface VehicleClient {

    @GetMapping("/vehicles/getAllVehicles")
    List<VehicleDTO> getAllVehicles();
}
