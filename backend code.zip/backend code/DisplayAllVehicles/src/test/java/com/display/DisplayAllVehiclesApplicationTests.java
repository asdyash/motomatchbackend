package com.display;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DisplayAllVehiclesApplicationTests {

	@Test
	void contextLoads() {
	}

}
