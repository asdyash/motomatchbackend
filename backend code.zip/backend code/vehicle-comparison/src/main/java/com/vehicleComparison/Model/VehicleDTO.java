package com.vehicleComparison.Model;



import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VehicleDTO {

    private String id;
    private String name;
    private String brand;
    private String model;
    private int year;
    private String description;
    private String type;
    private String engineSpecs;
    private String fuelType;
    private double price;

    
    // private double rating;
}
