package com.display.Controller;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import com.display.DTO.VehicleDTO;
import com.display.Service.DisplayService;

import java.util.List;

@RestController
@RequestMapping("/display")
@RequiredArgsConstructor
public class DisplayController {

    private final DisplayService displayService;

    @GetMapping("/vehicles")
    public List<VehicleDTO> getAllVehicles() {
        return displayService.fetchAllVehicles();
    }
}
