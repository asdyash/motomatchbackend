package com.reviewService.Controller;


import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.reviewService.Model.Review;
import com.reviewService.Service.ReviewService;

import java.util.List;

@RestController
@RequestMapping("/reviews")
@RequiredArgsConstructor
public class ReviewController {

    private final ReviewService reviewService;

    @PostMapping
    public ResponseEntity<Review> createReview(@Valid @RequestBody Review review) {
        return ResponseEntity.ok(reviewService.submitReview(review));
    }

    @GetMapping("/vehicle/{id}")
    public ResponseEntity<?> getReviewsByVehicle(@PathVariable String id,
                                                             @RequestHeader("Authorization") String token) {
        
        
        List<Review> reviews = reviewService.getReviewsByVehicle(id);
        return ResponseEntity.ok(reviews);
    }
    @GetMapping
    public ResponseEntity<?> getAllReviews(){
    	List<Review> review=reviewService.getAllReviews();
    	return ResponseEntity.ok(review);
    }

    
}
