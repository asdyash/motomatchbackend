package com.userservice.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.userservice.DTO.AuthResponse;
import com.userservice.DTO.LoginRequest;
import com.userservice.DTO.RegisterRequest;
import com.userservice.Model.UserEntity;
import com.userservice.Service.UserService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/auth")

public class UserController {
	@Autowired
     UserService userService;

    @PostMapping("/register")
    public UserEntity register(@RequestBody RegisterRequest request) {
        return userService.register(request);
    }

    @PostMapping("/login")
    public String login(@RequestBody LoginRequest request) {
        return userService.login(request);
    }
}