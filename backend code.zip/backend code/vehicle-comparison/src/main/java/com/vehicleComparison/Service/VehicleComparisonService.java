package com.vehicleComparison.Service;

import org.springframework.stereotype.Service;

import com.vehicleComparison.Client.VehicleServiceClient;
import com.vehicleComparison.Model.VehicleDTO;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class VehicleComparisonService {

    private final VehicleServiceClient vehicleClient;

    public String compareVehicles(String id1, String id2) {
        VehicleDTO v1 = vehicleClient.getVehicleById(id1);
        VehicleDTO v2 = vehicleClient.getVehicleById(id2);

        StringBuilder comparison = new StringBuilder();
        comparison.append("┌────────────────┬────────────────────────┬────────────────────────┐\n");
        comparison.append("│ Attribute      │ Vehicle 1              │ Vehicle 2              │\n");
        comparison.append("├────────────────┼────────────────────────┼────────────────────────┤\n");
        comparison.append(String.format("│ Name           │ %-22s │ %-22s │\n", v1.getName(), v2.getName()));
        comparison.append(String.format("│ Brand          │ %-22s │ %-22s │\n", v1.getBrand(), v2.getBrand()));
        comparison.append(String.format("│ Model          │ %-22s │ %-22s │\n", v1.getModel(), v2.getModel()));
        comparison.append(String.format("│ Year           │ %-22d │ %-22d │\n", v1.getYear(), v2.getYear()));
        comparison.append(String.format("│ Type           │ %-22s │ %-22s │\n", v1.getType(), v2.getType()));
        comparison.append("└────────────────┴────────────────────────┴────────────────────────┘\n");

        return comparison.toString();
    }
}