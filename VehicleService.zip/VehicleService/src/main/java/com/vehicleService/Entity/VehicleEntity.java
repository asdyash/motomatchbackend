package com.vehicleService.Entity;

import lombok.*;

import org.hibernate.validator.constraints.UniqueElements;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import jakarta.validation.constraints.*;

@Document(collection = "vehicles")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VehicleEntity {

    @Id
    private String id;

    @NotBlank(message = "Name is required")
    @Size(min = 2, max = 100, message = "Name must be between 2 and 100 characters")
    @UniqueElements
    private String name;

    @NotBlank(message = "Brand is required")
    private String brand;

    @NotBlank(message = "Model is required")
    private String model;

    @Min(value = 1886, message = "Year must be after 1885")
    @Max(value = 2100, message = "Year must be a valid future year")
    private int year;

    @NotBlank(message = "Description is required")
    @Size(max = 500, message = "Description must not exceed 500 characters")
    private String description;

    @NotBlank(message = "Type is required")
    private String type;

    @NotBlank(message = "Engine specifications are required")
    @Size(max = 100, message = "Engine specs must not exceed 100 characters")
    private String engineSpecs;

    @NotBlank(message = "Fuel type is required")
    private String fuelType;

    @Positive(message = "Price must be positive")
    private double price;
    private String imageUrl;
//    @DecimalMin(value = "0.0", inclusive = true, message = "Rating must be at least 0.0")
//    @DecimalMax(value = "5.0", inclusive = true, message = "Rating must not exceed 5.0")
//    private double rating;
}
